package com.example.documentsAPP.dto;

import com.example.documentsAPP.dto.AnexoSeguimientoData;
import com.example.documentsAPP.model.Company;
import com.example.documentsAPP.model.Course;
import com.example.documentsAPP.model.LearningResult;
import com.example.documentsAPP.model.Practice;
import com.example.documentsAPP.model.Student;
import com.example.documentsAPP.model.Trainee;
import com.example.documentsAPP.service.LearningResultService;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class AnexoSeguimientoDataBuilder {

    private final LearningResultService learningResultService;

    public AnexoSeguimientoDataBuilder(LearningResultService learningResultService) {
        this.learningResultService = learningResultService;
    }

    public AnexoSeguimientoData build(Practice practice, Student student) {
        Company company = practice.getCompany();
        Course course = student != null ? student.getCourse() : null;
        Trainee trainee = practice.getTrainee();

        List<LearningResult> learningResults = course != null
                ? learningResultService.findByCourseId(course.getId())
                : List.of();

        List<AnexoSeguimientoData.ResultadoFila> resultados = learningResults.stream()
                .map(lr -> AnexoSeguimientoData.ResultadoFila.builder()
                        .codigoModulo(n(lr.getSubjectCode()))
                        .raNumero(lr.getNumber() != null ? String.valueOf(lr.getNumber()) : "")
                        .build())
                .toList();

        LocalDate inicio = practice.getStartDate();
        LocalDate fin = practice.getEndDate();

        List<AnexoSeguimientoData.PeriodoSeguimiento> periodos =
                generarPeriodos(inicio, fin, resultados);

        return AnexoSeguimientoData.builder()
                .convenioNumero(n(practice.getAgreementNumber()))

                .alumnoApellidos(student != null ? n(student.getLastName()) : "")
                .alumnoNombre(student != null ? n(student.getFirstName()) : "")
                .alumnoCorreo(student != null ? n(student.getEmail()) : "")

                .entidadNombre(company != null ? n(company.getLegalName()) : "")
                .entidadTutorApellidos(trainee != null ? n(trainee.getLastName()) : "")
                .entidadTutorNombre(trainee != null ? n(trainee.getFirstName()) : "")
                .entidadTutorCorreo(trainee != null ? n(trainee.getEmail()) : "")

                .periodos(periodos)
                .build();
    }

    private List<AnexoSeguimientoData.PeriodoSeguimiento> generarPeriodos(
            LocalDate inicio,
            LocalDate fin,
            List<AnexoSeguimientoData.ResultadoFila> resultadosBase
    ) {
        List<AnexoSeguimientoData.PeriodoSeguimiento> lista = new ArrayList<>();
        if (inicio == null || fin == null || inicio.isAfter(fin)) {
            return lista;
        }

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy", new Locale("es", "ES"));

        LocalDate cursorInicio = inicio;

        LocalDate primerFin = finDePrimeraQuincena(cursorInicio);
        if (primerFin.isAfter(fin)) {
            primerFin = fin;
        }

        lista.add(AnexoSeguimientoData.PeriodoSeguimiento.builder()
                .fechaInicio(cursorInicio.format(fmt))
                .fechaFin(primerFin.format(fmt))
                .resultados(clonarResultados(resultadosBase))
                .build());

        cursorInicio = primerFin.plusDays(1);

        while (!cursorInicio.isAfter(fin)) {
            LocalDate bloqueFin = cursorInicio.plusDays(13);

            if (bloqueFin.getDayOfWeek() != DayOfWeek.SUNDAY) {
                bloqueFin = cursorInicio.plusDays(13);
            }

            if (bloqueFin.isAfter(fin)) {
                bloqueFin = fin;
            }

            lista.add(AnexoSeguimientoData.PeriodoSeguimiento.builder()
                    .fechaInicio(cursorInicio.format(fmt))
                    .fechaFin(bloqueFin.format(fmt))
                    .resultados(clonarResultados(resultadosBase))
                    .build());

            cursorInicio = bloqueFin.plusDays(1);
        }

        return lista;
    }

    private LocalDate finDePrimeraQuincena(LocalDate inicio) {
        int diasHastaDomingo = DayOfWeek.SUNDAY.getValue() - inicio.getDayOfWeek().getValue();
        if (diasHastaDomingo < 0) {
            diasHastaDomingo += 7;
        }

        LocalDate domingoSemanaInicio = inicio.plusDays(diasHastaDomingo);
        return domingoSemanaInicio.plusWeeks(1);
    }

    private List<AnexoSeguimientoData.ResultadoFila> clonarResultados(
            List<AnexoSeguimientoData.ResultadoFila> base
    ) {
        return base.stream()
                .map(r -> AnexoSeguimientoData.ResultadoFila.builder()
                        .codigoModulo(r.getCodigoModulo())
                        .raNumero(r.getRaNumero())
                        .build())
                .toList();
    }

    private String n(String s) {
        return s == null ? "" : s;
    }
}