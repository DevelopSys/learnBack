package com.example.documentsAPP.dto;

import com.example.documentsAPP.dto.Anexo9Data;
import com.example.documentsAPP.model.Company;
import com.example.documentsAPP.model.Course;
import com.example.documentsAPP.model.LearningResult;
import com.example.documentsAPP.model.Practice;
import com.example.documentsAPP.model.Student;
import com.example.documentsAPP.model.Trainee;
import com.example.documentsAPP.service.LearningResultService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

@Service
public class Anexo9DataBuilder {

    private final LearningResultService learningResultService;

    public Anexo9DataBuilder(LearningResultService learningResultService) {
        this.learningResultService = learningResultService;
    }

    public Anexo9Data build(Practice practice, Student student) {
        Company company = practice.getCompany();
        Course course = student != null ? student.getCourse() : null;
        Trainee trainee = practice.getTrainee();

        List<LearningResult> learningResults = course != null
                ? learningResultService.findByCourseId(course.getId())
                : List.of();

        List<Anexo9Data.ResultadoFila> resultados = learningResults.stream()
                .map(lr -> Anexo9Data.ResultadoFila.builder()
                        .codAsignatura(n(lr.getSubjectCode()))
                        .resultadoNumero(lr.getNumber() != null ? String.valueOf(lr.getNumber()) : "")
                        .build())
                .toList();

        LocalDate now = LocalDate.now();
        String dia = String.valueOf(now.getDayOfMonth());
        String mes = now.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES"));
        String anio = String.valueOf(now.getYear());

        return Anexo9Data.builder()
                .convenioNumero(n(practice.getAgreementNumber()))

                .alumnoNombre(student != null ? n(student.getFirstName()) : "")
                .alumnoApellido(student != null ? n(student.getLastName()) : "")
                .alumnoCorreo(student != null ? n(student.getEmail()) : "")

                .entidadNombre(company != null ? n(company.getLegalName()) : "")
                .entidadTutorNombre(trainee != null ? n(trainee.getFirstName()) : "")
                .entidadTutorApellido(trainee != null ? n(trainee.getLastName()) : "")
                .entidadTutorCorreo(trainee != null ? n(trainee.getEmail()) : "")

                .cursoNombre(course != null ? n(course.getName()) : "")
                .cursoCodigo(course != null ? n(course.getCode()) : "")
                .practicasHoras(practice.getTotalHours() != null ? String.valueOf(practice.getTotalHours()) : "")

                .dia(dia)
                .mes(mes)
                .anio(anio)

                .resultados(resultados)
                .build();
    }

    private String n(String s) {
        return s == null ? "" : s;
    }
}