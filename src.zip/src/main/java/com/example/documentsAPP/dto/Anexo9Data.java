package com.example.documentsAPP.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Anexo9Data {

    private String convenioNumero;

    private String alumnoApellido;
    private String alumnoNombre;
    private String alumnoCorreo;

    private String entidadNombre;
    private String entidadTutorApellido;
    private String entidadTutorNombre;
    private String entidadTutorCorreo;

    private String cursoNombre;
    private String cursoCodigo;
    private String practicasHoras;

    private String dia;
    private String mes;
    private String anio;

    private List<ResultadoFila> resultados;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResultadoFila {
        private String codAsignatura;
        private String resultadoNumero;
    }
}