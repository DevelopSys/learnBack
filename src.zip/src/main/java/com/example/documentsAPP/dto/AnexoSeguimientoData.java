package com.example.documentsAPP.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnexoSeguimientoData {

    private String convenioNumero;

    private String alumnoApellidos;
    private String alumnoNombre;
    private String alumnoCorreo;

    private String entidadNombre;
    private String entidadTutorApellidos;
    private String entidadTutorNombre;
    private String entidadTutorCorreo;

    private List<PeriodoSeguimiento> periodos;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PeriodoSeguimiento {
        private String fechaInicio;
        private String fechaFin;
        private List<ResultadoFila> resultados;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResultadoFila {
        private String codigoModulo;
        private String raNumero;
    }
}