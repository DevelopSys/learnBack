package com.example.documentsAPP.service;

import com.example.documentsAPP.dto.ConvenioAnexoData;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Service
public class AnexoConvenioDocxService {

    // TODO queda pendiente completar los datos de lugar fecha y cargo del representante (pendiente de confirmar)

    private static final String TEMPLATE_PATH = "/templates/1_Anexo.docx";

    public byte[] generarAnexo(ConvenioAnexoData data) {
        try (InputStream is = getClass().getResourceAsStream(TEMPLATE_PATH);
             XWPFDocument doc = new XWPFDocument(is)) {

            Map<String, String> values = buildPlaceholderMap(data);

            // Párrafos sueltos
            for (XWPFParagraph p : doc.getParagraphs()) {
                replaceInParagraph(p, values);
            }

            // Texto dentro de tablas
            for (XWPFTable table : doc.getTables()) {
                for (XWPFTableRow row : table.getRows()) {
                    for (XWPFTableCell cell : row.getTableCells()) {
                        for (XWPFParagraph p : cell.getParagraphs()) {
                            replaceInParagraph(p, values);
                        }
                    }
                }
            }
            int restantes = 0;
            for (XWPFParagraph p : doc.getParagraphs()) {
                String t = p.getText();
                if (t != null && t.contains("{{")) {
                    System.out.println("PARRAFO CON PLACEHOLDER: " + t);
                    restantes++;
                }
            }
            for (XWPFTable table : doc.getTables()) {
                for (XWPFTableRow row : table.getRows()) {
                    for (XWPFTableCell cell : row.getTableCells()) {
                        for (XWPFParagraph p : cell.getParagraphs()) {
                            String t = p.getText();
                            if (t != null && t.contains("{{")) {
                                System.out.println("CELDA CON PLACEHOLDER: " + t);
                                restantes++;
                            }
                        }
                    }
                }
            }
            System.out.println("Placeholders restantes: " + restantes);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            doc.write(bos);
            return bos.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("Error generando anexo de convenio", e);
        }
    }

    private Map<String, String> buildPlaceholderMap(ConvenioAnexoData d) {
        Map<String, String> m = new HashMap<>();

        // Convenio (en la plantilla actual solo se usa el número) [file:128]
        m.put("{{CONVENIO_NUMERO}}", n(d.convenioNumero()));

        // Centro docente (placeholders tal como están en el DOCX) [file:128]
        m.put("{{CENTRO_NOMBRE}}", n(d.centroNombre()));
        m.put("{{CENTRO_NIF}}", n(d.centroNif()));
        m.put("{{CENTRO_CODIGO}}", n(d.centroCodigo()));
        m.put("{{CENTRO_LOCALIDAD}}", n(d.centroLocalidad()));
        m.put("{{CENTRO_CALLE}}", n(d.centroCalle()));
        m.put("{{CENTRO_CP}}", n(d.centroCp()));
        m.put("{{CENTRO_PROVINCIA}}", n(d.centroProvincia()));
        m.put("{{CENTRO_PAIS}}", n(d.centroPais()));
        m.put("{{CENTRO_TITULAR_NOMBRE}}", n(d.centroTitularNombre()));
        m.put("{{CENTRO_TITULAR_NIF}}", n(d.centroTitularNif()));
        m.put("{{CENTRO_TITULAR_CARGO}}", n(d.centroTitularCargo()));

        // Firma “Fdo.: {{CENTRO_TITULAR}}” al final [file:128]
        m.put("{{CENTRO_TITULAR}}", n(d.centroTitularNombre()));

        // Entidad colaboradora [file:128]
        m.put("{{ENTIDAD_NOMBRE}}", n(d.entidadNombre()));
        m.put("{{ENTIDAD_NIF}}", n(d.entidadNif()));
        m.put("{{ENTIDAD_ACTIVIDAD}}", n(d.entidadActividad()));
        m.put("{{ENTIDAD_CALLE}}", n(d.entidadCalle()));
        m.put("{{ENTIDAD_CP}}", n(d.entidadCp()));
        m.put("{{ENTIDAD_LOCALIDAD}}", n(d.entidadLocalidad()));
        m.put("{{ENTIDAD_PROVINCIA}}", n(d.entidadProvincia()));
        m.put("{{ENTIDAD_PAIS}}", n(d.entidadPais()));
        // Si en el futuro añades teléfono en la plantilla:
        // m.put("{{ENTIDAD_TELEFONO}}", n(d.entidadTelefono()));

        // Representantes (plantilla solo usa nombre del 1º y 2º) [file:128]
        m.put("{{REP1_NOMBRE}}", n(d.rep1Nombre()));
        m.put("{{REP2_NOMBRE}}", n(d.rep2Nombre()));

        return m;
    }

    private String n(String s) {
        return s == null ? "" : s;
    }

    private void replaceInParagraph(XWPFParagraph paragraph, Map<String, String> values) {
        if (paragraph.getRuns() == null || paragraph.getRuns().isEmpty()) {
            return;
        }

        for (XWPFRun run : paragraph.getRuns()) {
            String text = run.getText(0);
            if (text == null || text.isEmpty()) continue;

            String newText = text;
            for (Map.Entry<String, String> e : values.entrySet()) {
                if (newText.contains(e.getKey())) {
                    newText = newText.replace(e.getKey(), e.getValue());
                }
            }

            if (!newText.equals(text)) {
                run.setText(newText, 0);
            }

            if (!newText.equals(text)) {
                System.out.println("Antes: " + text);
                System.out.println("Después: " + newText);
                run.setText(newText, 0);
            }
        }



    }
}