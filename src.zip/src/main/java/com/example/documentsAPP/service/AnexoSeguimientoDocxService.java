package com.example.documentsAPP.service;

import com.example.documentsAPP.dto.AnexoSeguimientoData;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTBody;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.*;

@Service
public class AnexoSeguimientoDocxService {

    private static final String TEMPLATE_PATH = "/templates/Anexo_8.docx";

    public byte[] generarAnexoSeguimiento(AnexoSeguimientoData data) {
        InputStream is = getClass().getResourceAsStream(TEMPLATE_PATH);
        if (is == null) {
            throw new IllegalStateException("Plantilla no encontrada en: " + TEMPLATE_PATH);
        }

        try (InputStream streamCerrado = is;
             XWPFDocument templateDoc = new XWPFDocument(streamCerrado);
             XWPFDocument outputDoc = new XWPFDocument()) {

            List<AnexoSeguimientoData.PeriodoSeguimiento> periodos = data.getPeriodos();
            if (periodos == null || periodos.isEmpty()) {
                throw new IllegalStateException("No hay periodos de seguimiento para generar");
            }

            for (int i = 0; i < periodos.size(); i++) {
                AnexoSeguimientoData.PeriodoSeguimiento periodo = periodos.get(i);

                try (XWPFDocument tempPageDoc = clonarDocumento(templateDoc)) {
                    Map<String, String> values = buildPlaceholderMap(data, periodo);

                    for (XWPFParagraph p : tempPageDoc.getParagraphs()) {
                        replaceInParagraph(p, values);
                    }

                    for (XWPFTable table : tempPageDoc.getTables()) {
                        procesarTablaRecursiva(table, values);
                    }

                    fillResultadosTable(tempPageDoc, periodo.getResultados());

                    appendDocument(outputDoc, tempPageDoc, i > 0);
                }
            }

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            outputDoc.write(bos);
            return bos.toByteArray();

        } catch (IOException e) {
            throw new IllegalStateException("Error generando anexo de seguimiento", e);
        }
    }

    private Map<String, String> buildPlaceholderMap(
            AnexoSeguimientoData data,
            AnexoSeguimientoData.PeriodoSeguimiento periodo
    ) {
        Map<String, String> m = new HashMap<>();

        putAll(m, "CONVENIO_NUMERO", n(data.getConvenioNumero()));

        putAll(m, "ALUMNO_APELLIDOS", n(data.getAlumnoApellidos()));
        putAll(m, "ALUMNO_NOMBRE", n(data.getAlumnoNombre()));
        putAll(m, "ALUMNO_CORREO", n(data.getAlumnoCorreo()));

        putAll(m, "ENTIDAD_NOMBRE", n(data.getEntidadNombre()));
        putAll(m, "ENTIDAD_TUTOR_APELLIDOS", n(data.getEntidadTutorApellidos()));
        putAll(m, "ENTIDAD_TUTOR_NOMBRE", n(data.getEntidadTutorNombre()));
        putAll(m, "ENTIDAD_TUTOR_CORREO", n(data.getEntidadTutorCorreo()));

        putAll(m, "FECHA_INICIO", n(periodo.getFechaInicio()));
        putAll(m, "FECHA_FIN", n(periodo.getFechaFin()));

        return m;
    }

    private void putAll(Map<String, String> map, String baseKey, String value) {
        map.put(baseKey, value);
        map.put("{{" + baseKey + "}}", value);
    }

    private String n(String s) {
        return s == null ? "" : s;
    }

    private void replaceInParagraph(XWPFParagraph paragraph, Map<String, String> values) {
        List<XWPFRun> runs = paragraph.getRuns();
        if (runs == null || runs.isEmpty()) return;

        StringBuilder fullText = new StringBuilder();
        for (XWPFRun run : runs) {
            String t = run.getText(0);
            fullText.append(t == null ? "" : t);
        }

        String texto = fullText.toString();

        boolean hayReemplazo = false;
        for (String key : values.keySet()) {
            if (texto.contains(key)) {
                hayReemplazo = true;
                break;
            }
        }
        if (!hayReemplazo) return;

        List<String> keys = new ArrayList<>(values.keySet());
        keys.sort((a, b) -> Integer.compare(b.length(), a.length()));

        for (String key : keys) {
            texto = texto.replace(key, values.get(key));
        }

        for (int i = 0; i < runs.size(); i++) {
            runs.get(i).setText(i == 0 ? texto : "", 0);
        }
    }

    private void procesarTablaRecursiva(XWPFTable table, Map<String, String> values) {
        for (XWPFTableRow row : table.getRows()) {
            for (XWPFTableCell cell : row.getTableCells()) {
                for (XWPFParagraph p : cell.getParagraphs()) {
                    replaceInParagraph(p, values);
                }
                for (XWPFTable nested : cell.getTables()) {
                    procesarTablaRecursiva(nested, values);
                }
            }
        }
    }

    private void fillResultadosTable(XWPFDocument doc, List<AnexoSeguimientoData.ResultadoFila> resultados) {
        if (resultados == null || resultados.isEmpty()) return;

        for (XWPFTable table : doc.getTables()) {
            XWPFTableRow plantilla = null;
            int plantillaIndex = -1;

            for (int i = 0; i < table.getRows().size(); i++) {
                XWPFTableRow row = table.getRow(i);
                for (XWPFTableCell cell : row.getTableCells()) {
                    String cellText = cell.getText();
                    if (cellText != null &&
                            (cellText.contains("{{CODIGO_MODULO}}")
                                    || cellText.contains("{{RA_NUMERO}}")
                                    || cellText.contains("CODIGO_MODULO")
                                    || cellText.contains("RA_NUMERO"))) {
                        plantilla = row;
                        plantillaIndex = i;
                        break;
                    }
                }
                if (plantilla != null) break;
            }

            if (plantilla == null) continue;

            List<List<List<String>>> textoOriginal = new ArrayList<>();
            for (XWPFTableCell cell : plantilla.getTableCells()) {
                List<List<String>> cellTexts = new ArrayList<>();
                for (XWPFParagraph p : cell.getParagraphs()) {
                    List<String> runTexts = new ArrayList<>();
                    for (XWPFRun run : p.getRuns()) {
                        String t = run.getText(0);
                        runTexts.add(t == null ? "" : t);
                    }
                    cellTexts.add(runTexts);
                }
                textoOriginal.add(cellTexts);
            }

            for (int idx = 0; idx < resultados.size(); idx++) {
                AnexoSeguimientoData.ResultadoFila ra = resultados.get(idx);
                XWPFTableRow currentRow;

                if (idx == 0) {
                    currentRow = plantilla;
                } else {
                    currentRow = table.insertNewTableRow(plantillaIndex + idx);
                    copyRowStructure(plantilla, currentRow);

                    List<XWPFTableCell> cells = currentRow.getTableCells();
                    for (int ci = 0; ci < cells.size() && ci < textoOriginal.size(); ci++) {
                        List<XWPFParagraph> paragraphs = cells.get(ci).getParagraphs();
                        List<List<String>> cellTexts = textoOriginal.get(ci);

                        for (int pi = 0; pi < paragraphs.size() && pi < cellTexts.size(); pi++) {
                            List<XWPFRun> runs = paragraphs.get(pi).getRuns();
                            List<String> runTexts = cellTexts.get(pi);

                            for (int ri = 0; ri < runs.size() && ri < runTexts.size(); ri++) {
                                runs.get(ri).setText(runTexts.get(ri), 0);
                            }
                        }
                    }
                }

                Map<String, String> m = new HashMap<>();
                putAll(m, "CODIGO_MODULO", n(ra.getCodigoModulo()));
                putAll(m, "RA_NUMERO", n(ra.getRaNumero()));

                for (XWPFTableCell cell : currentRow.getTableCells()) {
                    for (XWPFParagraph p : cell.getParagraphs()) {
                        replaceInParagraph(p, m);
                    }
                }
            }

            return;
        }
    }

    private void copyRowStructure(XWPFTableRow source, XWPFTableRow target) {
        if (source.getCtRow().getTrPr() != null) {
            target.getCtRow().setTrPr(source.getCtRow().getTrPr());
        }

        while (!target.getTableCells().isEmpty()) {
            target.removeCell(0);
        }

        for (XWPFTableCell sourceCell : source.getTableCells()) {
            XWPFTableCell newCell = target.addNewTableCell();

            if (sourceCell.getCTTc().getTcPr() != null) {
                newCell.getCTTc().setTcPr(sourceCell.getCTTc().getTcPr());
            }

            while (!newCell.getParagraphs().isEmpty()) {
                newCell.removeParagraph(0);
            }

            for (XWPFParagraph sourceParagraph : sourceCell.getParagraphs()) {
                XWPFParagraph newParagraph = newCell.addParagraph();

                if (sourceParagraph.getCTP().getPPr() != null) {
                    newParagraph.getCTP().setPPr(sourceParagraph.getCTP().getPPr());
                }

                for (XWPFRun sourceRun : sourceParagraph.getRuns()) {
                    XWPFRun newRun = newParagraph.createRun();

                    if (sourceRun.getCTR().getRPr() != null) {
                        newRun.getCTR().setRPr(sourceRun.getCTR().getRPr());
                    }

                    String t = sourceRun.getText(0);
                    newRun.setText(t == null ? "" : t, 0);
                }
            }
        }
    }

    private XWPFDocument clonarDocumento(XWPFDocument original) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        original.write(bos);
        return new XWPFDocument(new java.io.ByteArrayInputStream(bos.toByteArray()));
    }

    private void appendDocument(XWPFDocument target, XWPFDocument source, boolean pageBreakBefore) {
        CTBody targetBody = target.getDocument().getBody();
        CTBody srcBody = source.getDocument().getBody();

        if (pageBreakBefore && target.getParagraphs().size() > 0) {
            XWPFParagraph breakParagraph = target.createParagraph();
            breakParagraph.setPageBreak(true);
        }

        targetBody.set(srcBody);
    }
}