package com.example.documentsAPP.service;

import com.example.documentsAPP.dto.ConvenioAnexo4Data;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class Anexo4ConvenioDocxService {

    private static final String TEMPLATE_PATH = "/templates/4_Anexo.docx";

    public byte[] generarAnexo4(ConvenioAnexo4Data data) {
        InputStream is = getClass().getResourceAsStream(TEMPLATE_PATH);
        if (is == null) {
            throw new IllegalStateException("Plantilla no encontrada en: " + TEMPLATE_PATH);
        }

        try (InputStream streamCerrado = is;
             XWPFDocument doc = new XWPFDocument(streamCerrado)) {

            Map<String, String> values = buildPlaceholderMap(data);

            // 1. Párrafos sueltos del documento
            for (XWPFParagraph p : doc.getParagraphs()) {
                replaceInParagraph(p, values);
            }

            // 2. Tablas (cabeceras, textos fijos, etc.)
            for (XWPFTable table : doc.getTables()) {
                for (XWPFTableRow row : table.getRows()) {
                    for (XWPFTableCell cell : row.getTableCells()) {
                        for (XWPFParagraph p : cell.getParagraphs()) {
                            replaceInParagraph(p, values);
                        }
                    }
                }
            }

            // 3. Tabla de alumnos (fila plantilla clonada por alumno)
            fillAlumnosTable(doc, data);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            doc.write(bos);
            return bos.toByteArray();

        } catch (IOException e) {
            throw new IllegalStateException("Error generando anexo 4", e);
        }
    }

    // ─────────────────────────────────────────────────────────
    // MAPA DE PLACEHOLDERS GLOBALES
    // ─────────────────────────────────────────────────────────
    private Map<String, String> buildPlaceholderMap(ConvenioAnexo4Data d) {
        Map<String, String> m = new HashMap<>();

        // Cabecera convenio
        m.put("{{CONVENIO_NUMERO}}", n(d.getConvenioNumero()));
        m.put("{{CONVENIO_FECHA}}", n(d.getConvenioFecha()));

        // Centro docente
        m.put("{{CENTRO_NOMBRE}}", n(d.getCentroNombre()));
        m.put("{{ENTIDAD_NOMBRE}}", n(d.getEntidadNombre()));

        // Tutor centro
        m.put("{{CENTRO_TUTOR_APELLIDO}}", n(d.getCentroTutorApellido()));
        m.put("{{CENTRO_TUTOR_NOMBRE}}", n(d.getCentroTutorNombre()));
        m.put("{{CENTRO_TUTOR_DNI}}", n(d.getCentroTutorDni()));
        m.put("{{CENTRO_TUTOR_MAIL}}", n(d.getCentroTutorMail()));

        // Tutor empresa — con doble I tal como está en la plantilla Word
        m.put("{{ENTIDAD_TUTOR_APELLIDO}}", n(d.getEntidadTutorApellido()));
        m.put("{{ENTIIDAD_TUTOR_NOMBRE}}", n(d.getEntidadTutorNombre()));
        m.put("{{ENTIIDAD_TUTOR_DNI}}", n(d.getEntidadTutorDni()));
        m.put("{{ENTIDAD_TUTOR_MAIL}}", n(d.getEntidadTutorMail()));

        // Domicilio trabajo
        m.put("{{ENTIDAD_DOMICILIO_TRABAJO}}", n(d.getEntidadDomicilioTrabajo()));

        // Datos del ciclo
        m.put("{{CURSO_NOMBRE}}", n(d.getCursoNombre()));
        m.put("{{CURSO_NIVEL}}", n(d.getCursoNivel()));
        m.put("{{CURSO_CODIGO}}", n(d.getCursoCodigo()));

        // Número de alumnos
        int numAlumnos = d.getAlumnos() != null ? d.getAlumnos().size() : 0;
        m.put("{{NUM_ALUMNOS}}", String.valueOf(numAlumnos));

        // Fecha de firma
        m.put("{{FECHA_FIRMA}}", n(d.getFechaFirma()));

        return m;
    }

    private String n(String s) {
        return s == null ? "" : s;
    }

    // ─────────────────────────────────────────────────────────
    // REEMPLAZO ROBUSTO: une todos los runs, reemplaza y reescribe
    // Soluciona el problema de POI fragmentando los placeholders
    // ─────────────────────────────────────────────────────────
    private void replaceInParagraph(XWPFParagraph paragraph, Map<String, String> values) {
        List<XWPFRun> runs = paragraph.getRuns();
        if (runs == null || runs.isEmpty()) return;

        // 1. Unir el texto de todos los runs en un único String
        StringBuilder fullText = new StringBuilder();
        for (XWPFRun run : runs) {
            String t = run.getText(0);
            fullText.append(t == null ? "" : t);
        }

        String texto = fullText.toString();

        // 2. Comprobar si hay algo que reemplazar
        boolean hayReemplazo = false;
        for (String key : values.keySet()) {
            if (texto.contains(key)) {
                hayReemplazo = true;
                break;
            }
        }
        if (!hayReemplazo) return;

        // 3. Hacer todos los reemplazos sobre el texto completo
        for (Map.Entry<String, String> entry : values.entrySet()) {
            texto = texto.replace(entry.getKey(), entry.getValue());
        }

        // 4. Primer run recibe todo el texto, el resto se vacían
        for (int i = 0; i < runs.size(); i++) {
            runs.get(i).setText(i == 0 ? texto : "", 0);
        }
    }

    // ─────────────────────────────────────────────────────────
    // TABLA DE ALUMNOS
    // ─────────────────────────────────────────────────────────
    private void fillAlumnosTable(XWPFDocument doc, ConvenioAnexo4Data data) {
        if (data.getAlumnos() == null || data.getAlumnos().isEmpty()) return;

        for (XWPFTable table : doc.getTables()) {
            XWPFTableRow plantilla = null;
            int plantillaIndex = -1;

            // 1. Buscar la fila que contiene el placeholder de alumno
            for (int i = 0; i < table.getRows().size(); i++) {
                XWPFTableRow row = table.getRow(i);
                for (XWPFTableCell cell : row.getTableCells()) {
                    String cellText = cell.getText();
                    if (cellText != null && cellText.contains("ALUMNO_APELLIDO")) {
                        plantilla = row;
                        plantillaIndex = i;
                        break;
                    }
                }
                if (plantilla != null) break;
            }

            if (plantilla == null) continue;

            // 2. Guardar texto original de cada run ANTES de tocar nada
            List<List<List<String>>> textoOriginal = new ArrayList<>();
            for (XWPFTableCell cell : plantilla.getTableCells()) {
                List<List<String>> cellTexts = new ArrayList<>();
                for (XWPFParagraph p : cell.getParagraphs()) {
                    List<String> runTexts = new ArrayList<>();
                    for (XWPFRun run : p.getRuns()) {
                        String t = run.getText(0);
                        runTexts.add(t == null ? "" : t);
                    }
                    cellTexts.add(runTexts);
                }
                textoOriginal.add(cellTexts);
            }

            // 3. Para cada alumno, rellenar o clonar fila
            for (int idx = 0; idx < data.getAlumnos().size(); idx++) {
                ConvenioAnexo4Data.AlumnoFila al = data.getAlumnos().get(idx);
                XWPFTableRow currentRow;

                if (idx == 0) {
                    // El primer alumno usa la fila plantilla directamente
                    currentRow = plantilla;
                } else {
                    // Los siguientes: clonar estructura y restaurar texto original
                    currentRow = table.insertNewTableRow(plantillaIndex + idx);
                    copyRowStructure(plantilla, currentRow);

                    // Restaurar placeholders originales en la fila clonada
                    List<XWPFTableCell> cells = currentRow.getTableCells();
                    for (int ci = 0; ci < cells.size() && ci < textoOriginal.size(); ci++) {
                        List<XWPFParagraph> paragraphs = cells.get(ci).getParagraphs();
                        List<List<String>> cellTexts = textoOriginal.get(ci);
                        for (int pi = 0; pi < paragraphs.size() && pi < cellTexts.size(); pi++) {
                            List<XWPFRun> runs = paragraphs.get(pi).getRuns();
                            List<String> runTexts = cellTexts.get(pi);
                            for (int ri = 0; ri < runs.size() && ri < runTexts.size(); ri++) {
                                runs.get(ri).setText(runTexts.get(ri), 0);
                            }
                        }
                    }
                }

                // 4. Mapa de sustitución para este alumno
                Map<String, String> m = new HashMap<>();
                m.put("{{ALUMNO_APELLIDO}}", n(al.getAlumnoApellido()));
                m.put("{{ALUMNO_NOMBRE}}", n(al.getAlumnoNombre()));
                m.put("{{ALUMNO_DNI}}", n(al.getDni()));
                m.put("{{ALUMNO_FECHA}}", n(al.getFechaNacimiento()));
                m.put("{{PRACTICA_INICIO}}", n(al.getPracticaInicio()));
                m.put("{{PRACTICA_FIN}}", n(al.getPracticaFin()));
                m.put("{{PRACTICA_DIAS}}", n(al.getPracticaDias()));
                m.put("{{PRACTICA_HORA_INICIO}}", n(al.getPracticaHoraInicio()));
                m.put("{{PRACTICA_HORA_FIN}}", n(al.getPracticaHoraFin()));
                m.put("{{PRACTICA_HORA_FIN}", n(al.getPracticaHoraFin())); // por si hay llave rota en la plantilla
                m.put("{{PRACTICA_HORA_SEMANA}}", n(al.getPracticaHorasSemana()));
                m.put("{{PRACTICA_HORAS_TOTAL}}", n(al.getPracticaHorasTotal()));

                // 5. Número de orden (01, 02...) en la primera celda
                if (!currentRow.getTableCells().isEmpty()) {
                    XWPFTableCell c0 = currentRow.getCell(0);
                    for (XWPFParagraph p : c0.getParagraphs()) {
                        List<XWPFRun> runs = p.getRuns();
                        if (runs != null && !runs.isEmpty()) {
                            runs.get(0).setText(n(al.getNumero()), 0);
                            for (int r = 1; r < runs.size(); r++) {
                                runs.get(r).setText("", 0);
                            }
                        }
                    }
                }

                // 6. Reemplazar placeholders en todas las celdas de la fila
                for (XWPFTableCell cell : currentRow.getTableCells()) {
                    for (XWPFParagraph p : cell.getParagraphs()) {
                        replaceInParagraph(p, m);
                    }
                }
            }
            return; // Solo procesamos la primera tabla de alumnos
        }
    }

    // ─────────────────────────────────────────────────────────
    // CLONAR ESTRUCTURA DE FILA (mantiene formato)
    // ─────────────────────────────────────────────────────────
    private void copyRowStructure(XWPFTableRow source, XWPFTableRow target) {
        if (source.getCtRow().getTrPr() != null) {
            target.getCtRow().setTrPr(source.getCtRow().getTrPr());
        }

        while (!target.getTableCells().isEmpty()) {
            target.removeCell(0);
        }

        for (XWPFTableCell sourceCell : source.getTableCells()) {
            XWPFTableCell newCell = target.addNewTableCell();

            if (sourceCell.getCTTc().getTcPr() != null) {
                newCell.getCTTc().setTcPr(sourceCell.getCTTc().getTcPr());
            }

            while (!newCell.getParagraphs().isEmpty()) {
                newCell.removeParagraph(0);
            }

            for (XWPFParagraph sourceParagraph : sourceCell.getParagraphs()) {
                XWPFParagraph newParagraph = newCell.addParagraph();

                if (sourceParagraph.getCTP().getPPr() != null) {
                    newParagraph.getCTP().setPPr(sourceParagraph.getCTP().getPPr());
                }

                for (XWPFRun sourceRun : sourceParagraph.getRuns()) {
                    XWPFRun newRun = newParagraph.createRun();
                    if (sourceRun.getCTR().getRPr() != null) {
                        newRun.getCTR().setRPr(sourceRun.getCTR().getRPr());
                    }
                    String t = sourceRun.getText(0);
                    newRun.setText(t == null ? "" : t, 0);
                }
            }
        }
    }
}