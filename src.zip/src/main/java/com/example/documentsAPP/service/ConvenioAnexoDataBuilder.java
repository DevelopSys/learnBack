package com.example.documentsAPP.service;

import com.example.documentsAPP.dto.ConvenioAnexoData;
import com.example.documentsAPP.model.Agreement;
import com.example.documentsAPP.model.Company;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service
public class ConvenioAnexoDataBuilder {

    // Podrías inyectar un repositorio de parámetros/centro o usar propiedades
    @Value("${centro.nombre:CES JUAN PABLO II}")
    private String centroNombre;
    @Value("${centro.nif:111111X}")
    private String centroNif;
    @Value("${centro.codigo:289765}")
    private String centroCodigo;
    @Value("${centro.localidad:Alcorcón}")
    private String centroLocalidad;
    @Value("${centro.calle:calle Estocolmo}")
    private String centroCalle;
    @Value("${centro.cp:28901}")
    private String centroCp;
    @Value("${centro.provincia:Madrid}")
    private String centroProvincia;
    @Value("${centro.pais:España}")
    private String centroPais;
    @Value("${centro.titular.nombre:Isaac Sampredo Luna}")
    private String centroTitularNombre;
    @Value("${centro.titular.nif:000001}")
    private String centroTitularNif;
    @Value("${centro.titular.cargo:Titular}")
    private String centroTitularCargo;

    public ConvenioAnexoData build(Company company, Agreement agreement) {
        // asumo que company.getRepresentatives() devuelve lista
        var reps = company.getRepresentatives();
        var rep1 = reps != null && !reps.isEmpty() ? reps.get(0) : null;
        var rep2 = reps != null && reps.size() > 1 ? reps.get(1) : null;

        String fechaConvenio = agreement.getSignDate() != null
                ? agreement.getSignDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                : "";

        return new ConvenioAnexoData(
                // convenio
                agreement.getNumber(),
                fechaConvenio,
                company.getCity(), // o lo que quieras como lugar de firma

                // centro
                centroNombre,
                centroNif,
                centroCodigo,
                centroLocalidad,
                centroCalle,
                centroCp,
                centroProvincia,
                centroPais,
                centroTitularNombre,
                centroTitularNif,
                centroTitularCargo,

                // entidad
                company.getLegalName(),
                company.getNif(),
                company.getActivity(),
                company.getStreet(),
                company.getPostalCode(),
                company.getCity(),
                company.getProvince(),
                company.getCountry(),
                company.getPhone(),
                company.getLegalName(),       // denominación
                company.getActivity(),        // naturaleza/competencias (puedes refinar)

                // rep1
                rep1 != null ? rep1.getFullName() : "",
                // rep1 != null ? rep1.getCargo() : "",
                // rep1 != null ? rep1.getBaseNormativa() : "",

                // rep2
                rep2 != null ? rep2.getFullName() : ""
                // rep2 != null ? rep2.getCargo() : "",
                // rep2 != null ? rep2.getNombradoPor() : "",
                // rep2 != null ? rep2.getBaseNormativa() : ""
        );
    }
}